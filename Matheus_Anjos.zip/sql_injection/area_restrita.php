<?php 
echo "<h1> 🚨 Área restrita 🚨</h1>";
echo "<p>Você não deveria estar aqui, mas conseguiu acessar devido a uma falha de segurança!</p>";
echo"<p>Isso mostra como ataques SQL injection podem comprometer sistemas sem proteção adequada.</p>";
?>